Instagram Follower Collector
----------------------------

인스타그램 유저의 팔로워 정보를 수집하는 프로그램입니다.

## 사용법

```bash
$ python ./main.py [force] <username>
```

또는

```bash
$ ./start.sh <config_file> <username>
$ nohup ./start.sh config_15g_korea.py 15g_korea & 
```

## 준비사항

- sqlite3
- python 2.7
- pip

## 설치

**소스 다운로드**

**virtualenv**

```bash
$ pip install virtualenv
$ cd insta_follower_collector
$ virtualenv -p python2.7 env
$ . env/bin/activate
$ pip install --upgrade pip
```

**패키지 설치**

```bash
$ pip install -r requirements.txt
$ python ./install_imageio.py
```

## 설정

`config.py`를 만든다. `-c|--config` 옵션을 이용하면 다른 설정파일을 지정할 수가 있다.

설정파일은 반드시 `py` 확장자를 가져야한다.

```bash
$ cp config.sample.py config.py
```

**config.py**

```bash
database_name = 'data.db'
account = {'username': 'myaccount1', 'password': 'mypassword1'}
```
`database_name`에 원하는 데이터 베이스 이름을 입력한다. `account`에는 포맷에 맞추어 계정 정보를 입력한다.

## 실행절차

1. Target 유저의 팔로워를 수집
2. 수집된 Follower의 정보 수집
3. DB 저장
4. SQL을 통한 통계

## 실행

```bash
$ python ./main.py <username>
```

**옵션**

* `[-f | --force]`: Target 유저의 팔로워를 이미 받았어도 다시 받는다.(사용자 정보는 갱신하지 않음)
* `[-c | --config]`: config 파일을 직접 지정한다. 지정하지 않을 경우에는 `config.py`을 사용한다.​

또는

```bash
$ ./start.sh <config_file> <username>
```

ex)

```bash
$ python ./main.py --force -c config_second insta_username
```

```bash
$ ./start.sh config_second insta_username
```


**참고사항**

1. Target 유저의 팔로워를 수집할때에 중간에 멈추면 처음부터 다시 수집한다.
2. 수집된 팔로워의 정보를 수집중에 멈추게 되면 다음 실행때에는 마지막으로 수집한 팔로워부터 이어서 수집한다.
3. 한 계정당 일정기간동안 API를 호출할 수 있는 횟수가 정해져있다.
4. 한 DB에 여러 Target 유저의 팔로워 정보를 수집할 수 있다.
5. 이미 Target 유저의 팔로워 수집을 정상적으로 완료한 경우라면 다시 수집을 하지 않는다.
6. 5의 경우라도 `[-f | --force]` 옵션을 이용하면 다시 수집할 수가 있다.
7. `[-c | --config]` 옵션을 이용하면 여러 계정과 DB에 동시에 쓸수있다.

## 데이터

**Console을 이용**

```bash
$ sqlite3 data.db

sqlite>
```

**sqlite client를 이용**

 - SQLPro for SQLite: `https://www.sqlitepro.com/` 또는 `app store`

**SQL**

```sql
SELECT u.* FROM users_tbl u LEFT JOIN followers_tbl f ON u.username_id = f.username_id
WHERE f.targetname = '0.8l_korea'
ORDER BY u.id
```

```sql
SELECT u.* FROM users_tbl u LEFT JOIN followers_tbl f ON u.username_id = f.username_id
WHERE f.targetname = '0.8l_korea' and u.follower_count > 1000
ORDER BY u.id
```

## 서버에서 실행

1. 필요한 패키지 설치(위에 참조)

2. ffmpeg 설치

    ```bash
    $ python ./install_imageio.py
    ```

3. Config 파일 생성 및 수정

    ```bash
    $ cp config.sample.py config_1.py
    ```

    `config_1.py` 수정​

    ```python
    database_name = 'data.db'
    account = {'username': 'my_account_name', 'password': 'my_password'}
    ```

4. 실행

    ```bash
    $ nohup ./start.sh config_1.py 0.8l_korea &
    ```

5. 진행사항 확인

    ```bash
    # 개별 확인
    $ tail -f logs/0.8l_korea.log

    # 전체 확인
    $ tail -f nohup.out
    ```

6. Log 확인

   ```bash
   $ cat logs/0.8l_korea.log
   ```
   마지막에 `Result: ? / ?`과 `Total Users:` 을 확인하고 이상이 있으면 3번부터 다시 실행한다.

7. 결과

   ```bash
   $ ls -l dist/
   total 8
   -rw-r--r--  1 harry  staff   991B Mar 16 11:13 harryoh__.csv
    ```

## 초기화​

```bash
$ git clean -f n .
```

또는

```bash
$ rm -f logs/*
$ rm -f dist/*
$ rm -f *.db
```

# AWS Server Manage

```json
    - user
        ununtu/01063373657
        root/01063373657
    - crawler 작업 위치
        /home/ubuntu/crawler    
    - 리소스 모니터링 설치 및 사용 법
        설치: sudo apt-get -y install htop
        사용: htop
    - 실행중인 프로세스 확인
        파이썬 실행 프로세스 확인 방법: ps -aux | grep python       
    - 파일 관리 (Filezila 대용)
        rz/sz는 ZMODEM을 이용하는 명령이라고 하며 rb/sb는 YMODEM, rx/sx는 XMODEM을 사용 한다.
        여기서는 zmodem 을 사용하도록 한다.
        설치: sudo apt-get -y install lrzsz 
        사용: 
            서버로부터 다운 받을때 : sz <파일명>
                다운 받은 파일은 (zoc 7 프로그램 기준) 유저의 다운로드 폴더가 된다. [다운 로드 위치를 변경 가능]
            로컬에서 서버로 업로드 : rz -> 파일 업로드 창이 생김 -> 원하는 파일 선택
                업로드 된 파일은 실행시킨 위치가 된다.
```