# -*- coding: utf-8 -*-
from time import sleep
from collections import defaultdict
from libs.InstagramAPI import InstagramAPI


class InstaFollowers(InstagramAPI, object):
    def __init__(self, username, password, targetname, logger=None):
        super(InstaFollowers, self).__init__(username, password)
        self.follower_count = 0
        self.next_max_id = ''
        self.target = defaultdict()
        self.logger = logger
        self.login()
        if self.LastStatusCode == 200:
            self.target = self.target_info(targetname)

    def _errorlog(self, message):
        if self.logger:
            self.logger.error(message)

    def _get_followers(self, target_id, next_id):
        if self.getUserFollowers(target_id, next_id):
            if len(self.LastJson['users']) and self.LastJson['big_list']:
                self.next_max_id = self.LastJson['next_max_id']
            return self.LastJson['users'], self.next_max_id
        else:
            raise ValueError(self.LastJson['message'])

    def get_target(self):
        return self.target

    def set_target(self, target):
        self.target = target

    def target_info(self, username):
        if self.searchUsername(username):
            self.target = self.LastJson['user']
            return self.target
        else:
            raise ValueError('Can\'t find {} user'.format(username))

    def get_user(self, user_id):
        if self.getUsernameInfo(user_id):
            return self.LastJson['user']
        else:
            if self.LastStatusCode == 404:
                raise ValueError('Not found user({})'.format(user_id))
            else:
                raise ValueError(self.LastJson['message'])

    def get_followers(self):
        getcount = 0
        next_id = ''
        total = self.target['follower_count']
        target_id = self.target['pk']

        while (getcount < total):
            try:
                followers, next_id = self._get_followers(target_id, next_id)
            except ValueError as e:
                self._errorlog('Error: {}(status_code:{})'
                               .format(str(e), self.LastStatusCode))
                self._errorlog('Trying again after 5 minutes....')
                sleep(60 * 5)
                continue

            for follower in followers:
                getcount += 1
                yield follower
            if not next_id:
                break
