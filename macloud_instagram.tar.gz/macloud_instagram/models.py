# -*- coding: utf-8 -*-
import datetime
from peewee import Model, SqliteDatabase, Proxy
from peewee import (
    CharField, DateTimeField, IntegerField, BooleanField, ForeignKeyField,
    TextField)

from constants import HISTORY_RESULTS

db = Proxy()


class BaseModel(Model):
    class Meta:
        database = db


class Users(BaseModel):
    class Meta:
        db_table = 'users_tbl'

    username = CharField(null=False)
    username_id = CharField(null=False, index=True, unique=True)
    full_name = CharField()
    usertags_count = IntegerField(default=0)
    media_count = IntegerField(default=0)
    following_count = IntegerField(default=0, index=True)
    follower_count = IntegerField(default=0, index=True)
    is_business = BooleanField(default=False)
    is_private = BooleanField(default=False)
    created_at = DateTimeField(default=datetime.datetime.now)


class History(BaseModel):
    class Meta:
        db_table = 'history_tbl'
        order_by = ['-created_at']
        indexes = (
            (('targetname', 'result_key'), False),
        )

    targetname = CharField(null=False, index=True)
    targetname_id = CharField(null=False)
    request_username = CharField(null=False)
    follower_count = IntegerField(default=0)
    result_key = IntegerField(default=0, choices=HISTORY_RESULTS)
    memo = TextField(null=True)
    created_at = DateTimeField(default=datetime.datetime.now, index=True)


class Followers(BaseModel):
    class Meta:
        db_table = 'followers_tbl'

    history = ForeignKeyField(History)
    targetname = CharField(null=False)
    targetname_id = CharField(null=False, index=True)
    username_id = CharField(null=False, index=True)
    username = CharField(null=False, index=True)
    created_at = DateTimeField(default=datetime.datetime.now)


def initialize_database(database_name):
    db.initialize(SqliteDatabase(database_name))
    Users.create_table(True)
    History.create_table(True)
    Followers.create_table(True)


def get_db():
    return db
