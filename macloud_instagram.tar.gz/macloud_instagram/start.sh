#!/bin/bash

python_script='
import sys
d = {}
exec(open(sys.argv[1], "r").read()) in d
for k in sys.argv[2:]:
    print "%s\0" % str(d[k]).split("\0")[0]
'

sql_tmpl='
SELECT u.* FROM users_tbl u LEFT JOIN followers_tbl f ON u.username_id = f.username_id
WHERE f.targetname = "{{targetname}}"
ORDER BY u.id;
'

read_python_vars() {
    config=$1
    if [ "${config: -3}" != '.py' ]; then
        config="$config.py"
    fi

    local python_file=$config; shift
    local varname
    for varname; do
        IFS= read -r -d '' "${varname#*:}"
    done < <(python -c "$python_script" "$python_file" "${@%%:*}")
}

export_csv() {
    if [ ! -d 'dist' ]; then
        mkdir dist
    fi
    database=$1
    targetname=$2
    csvfile="dist/${targetname}.csv"
    sql=${sql_tmpl/\{\{targetname\}\}/$targetname}
    printf '\xEF\xBB\xBF' > $csvfile
    sqlite3 -header -csv $database "$sql" >> $csvfile
}


if [ -z "$2" ]; then
    echo "Usage: ${0} <config file> <username>"
    echo "ex) ${0} config_1 0.8l_korea"
    exit 1
fi

CONFIG=$1
TARGETNAME=$2

read_python_vars $CONFIG database_name:DATABASE
python ./main.py $TARGETNAME -c $CONFIG
export_csv $DATABASE $TARGETNAME
