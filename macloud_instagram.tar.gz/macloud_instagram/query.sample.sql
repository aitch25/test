SELECT u.* FROM users_tbl u LEFT JOIN followers_tbl f ON u.username_id = f.username_id
WHERE f.targetname = '{{targetname}}'
ORDER BY u.id;
