# -*- coding: utf-8 -*-
import os
import logging
import optparse
from importlib import import_module
from time import sleep
from datetime import datetime, timedelta
from peewee import JOIN

from insta_followers import InstaFollowers
from models import initialize_database, get_db, History, Followers, Users
from constants import (
    HISTORY_RESULT_START, HISTORY_RESULT_WORKING, HISTORY_RESULT_COLLECTED,
    HISTORY_RESULT_ANLYSIS, HISTORY_RESULT_DONE, HISTORY_RESULT_FAIL)

logger = logging.getLogger('app')


def collect_followers(accounts):
    db = get_db()
    insta = accounts[0]
    target = insta.get_target()
    followers = insta.get_followers()
    update_time = datetime.now()
    count = 0
    total_followers = target['follower_count']

    history = History.create(
        targetname=target['username'],
        targetname_id=target['pk'],
        request_username=accounts[0].username,
        follower_count=total_followers,
        result_key=HISTORY_RESULT_WORKING[0],
        memo='force'
    )

    with db.atomic():
        try:
            query = (Followers
                     .delete()
                     .where(Followers.targetname_id == target['pk']))
            query.execute()

            for follower in followers:
                Followers.create(
                    history=history,
                    username_id=follower['pk'],
                    username=follower['username'],
                    targetname_id=target['pk'],
                    targetname=target['username']
                )

                # Print Progress
                if datetime.now() > update_time:
                    logger.info('{}/{} {:.2f}%'.format(
                        count, total_followers,
                        float(count)/float(total_followers)*100))
                    update_time = datetime.now() + timedelta(seconds=3)
                count += 1
        except Exception as e:
            logger.error('Error: {} (status_code:{})'
                         .format(str(e), insta.LastStatusCode))
            db.rollback()
            history.result_key = HISTORY_RESULT_FAIL[0]
            history.save()
            return history, target['follower_count'], 0

    history.result_key = HISTORY_RESULT_COLLECTED[0]
    history.save()
    return history, target['follower_count'], count


def analysis_followers(accounts, history=None):
    count = 0
    update_time = datetime.now()
    target = accounts[0].get_target()

    if not history:
        history = (History
                   .select()
                   .where(History.targetname == target['username'],
                          History.result_key >= HISTORY_RESULT_COLLECTED[0])
                   .get())

    history.result_key = HISTORY_RESULT_ANLYSIS[0]
    history.save()

    followers = (Followers
                 .select()
                 .join(Users, JOIN.LEFT_OUTER,
                       on=(Followers.username_id == Users.username_id))
                 .where(Followers.targetname_id == target['pk'],
                        Followers.history == history))

    total_followers = followers.count()
    followers = followers.where(Users.id.is_null(True))
    remain = followers.count()
    count = total_followers - remain
    removed_user = 0

    for i, follower in enumerate(followers):
        curr = accounts[i % len(accounts)]
        try:
            insta_user = curr.get_user(follower.username_id)
            Users.create(
                username=insta_user['username'],
                username_id=insta_user['pk'],
                full_name=insta_user['full_name'],
                usertags_count=insta_user['usertags_count'],
                media_count=insta_user['media_count'],
                following_count=insta_user['following_count'],
                follower_count=insta_user['follower_count'],
                is_business=insta_user['is_business'],
                is_private=insta_user['is_private'],
            )

            # Print Progress
            if datetime.now() > update_time:
                logger.info('{}/{} {:.2f}%'.format(
                    count, total_followers,
                    float(count)/float(total_followers)*100))
                update_time = datetime.now() + timedelta(seconds=3)
            count += 1
        except Exception as e:
            logger.error('Error: {}(status_code={})'
                         .format(str(e), curr.LastStatusCode))
            if curr.LastStatusCode == 404:
                logger.warning('Not found {} user'.format(follower.username))
                f = Followers.get(Followers.username_id == follower.username_id)
                f.delete_instance()
                removed_user += 1
                continue
            if str(e).startswith('HTTPSConnectionPool'):
                logger.warning('Timeout: {}'.format(follower.username))
                sleep(5)
                continue

            logger.error('Trying again after 5 minutes....')
            sleep(60 * 5)
            continue

    if count >= total_followers:
        history.result_key = HISTORY_RESULT_DONE[0]
        history.save()

    return (total_followers - removed_user), remain, count


def main():
    history = None
    total = 0
    count = 0
    accounts = []

    usage = 'usage: %prog [options] target_username'
    parser = optparse.OptionParser(usage=usage)
    parser.add_option('-c', '--config',
                      action='store', dest='config',
                      help='config file', default='config')
    parser.add_option('-f', '--force',
                      action='store_true', dest='force',
                      help='force get followers', default=False)

    options, args = parser.parse_args()
    if options.config.endswith('.py'):
        options.config = options.config[:-3]
    config = import_module(options.config)
    targetname = args[0]
    log_file = os.path.join(os.getcwd(), 'logs/{}.log'.format(targetname))

    formatter = logging.Formatter('[%(levelname)s|%(asctime)s] %(message)s')
    sto = logging.StreamHandler()
    sto.setFormatter(formatter)
    hdlr = logging.FileHandler(log_file)
    hdlr.setFormatter(formatter)
    logger.addHandler(sto)
    logger.addHandler(hdlr)
    logger.setLevel(logging.INFO)

    logger.info('-' * 30)
    logger.info('Start collect \'{}\' followers'.format(targetname))
    logger.info(' * Config: {}'.format(options.config))
    logger.info(' * Database: {}'.format(config.database_name))

    initialize_database(config.database_name)
    for account in config.accounts:
        curr = InstaFollowers(account['username'],
                              account['password'],
                              targetname,
                              logger)
        if curr.LastStatusCode != 200:
            logger.warning('Wrong account information(username:{})'
                           .format(account['username']))
            continue
        else:
            logger.info('{} login success'.format(account['username']))

        accounts.append(curr)
    target = accounts[0].get_target()
    if target['is_private'] is True:
        logger.error('{} is a private user'.format(targetname))
        return False

    is_exist = History.select().where(
        History.targetname == targetname,
        History.result_key >= HISTORY_RESULT_COLLECTED[0]
    ).count()

    logger.info('----- Start Getting Followers -----')

    if options.force or not is_exist:
        history, total, count = collect_followers(accounts)
        # Print Result
        logger.info('{}/{} {:.2f}%'
                    .format(count, total, float(count)/float(total)*100))
        logger.info('Result: {} / {}'.format(count, total))
        if count < total:
            logger.warning('{} user remain!!'.format((total-count)))
        logger.info('-----')
    else:
        logger.info('{} followers list is already exist'.format(targetname))

    logger.info('----- Analysis Followers -----')
    total, remain, count = analysis_followers(accounts, history)
    if remain:
        logger.info('{}/{} {:.2f}%'
                    .format(count, total, float(count)/float(total)*100))
        logger.info('Result: {} / {}'.format(count, total))
        if count < total:
            logger.warning('{} user remain!!'.format((total-count)))
        logger.info('-----')
    else:
        logger.info('{} followers analysis is already done.'.format(targetname))

    logger.info('----- Complete -----')
    logger.info('Total Users: {}'.format(count))

if __name__ == "__main__":
    main()
