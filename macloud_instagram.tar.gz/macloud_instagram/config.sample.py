database_name = 'database name to store data'
accounts = [
    {'username': '', 'password': ''},
]
